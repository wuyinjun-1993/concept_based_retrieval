from collections import defaultdict, deque
from .raptor_src import RetrievalAugmentation
import os
import torch

class RaptorEmbeddingGenerator:
    def __init__(self):
        self.RA = RetrievalAugmentation()

    def add_node(self, parent, children):
        self.nodes_dict[parent].extend(children)
        for child in children:
            self.parent_map[child].append(parent)

    def set_leaf_coverage(self, node, coverage):
        self.coverage_dict[node] = coverage

    def calculate_coverages(self):
        # A dictionary to store the number of children (out-degree) for each node
        out_degree = defaultdict(int)
        for parent, children in self.nodes_dict.items():
            out_degree[parent] += len(children)

        # Queue for processing nodes with no unprocessed children
        queue = deque()

        # Start with leaf nodes (nodes with no children)
        for node in self.nodes_dict:
            if out_degree[node] == 0:
                queue.append(node)

        while queue:
            current = queue.popleft()

            # Calculate the range for the current node based on its children's ranges
            if current not in self.coverage_dict:
                min_val = float('inf')
                max_val = float('-inf')
                for child in self.nodes_dict[current]:
                    if child in self.coverage_dict:
                        child_min, child_max = self.coverage_dict[child]
                        min_val = min(min_val, child_min)
                        max_val = max(max_val, child_max)
                if min_val != float('inf') and max_val != float('-inf'):
                    self.coverage_dict[current] = (min_val, max_val)

            # Reduce the out-degree of its parent nodes and add them to the queue if ready
            for parent in self.parent_map[current]:
                out_degree[parent] -= 1
                if out_degree[parent] == 0:
                    queue.append(parent)

    def process_tree(self, tree):
        # Clear the dictionaries
        self.nodes_dict = defaultdict(list)
        self.coverage_dict = {}
        self.parent_map = defaultdict(list)

        #starting_idx = 0
        leaf_nodes = []
        for key, value in tree.all_nodes.items():
            if value.children == set():
                self.add_node(key, [])
            else:
                self.add_node(key, list(value.children))

        for key, value in tree.leaf_nodes.items():
            #ending_idx = starting_idx + len(value.text)
            self.set_leaf_coverage(key, (key, key+1))
            leaf_nodes.append(key)
            #starting_idx = ending_idx + 1

        self.calculate_coverages()

        patch_activations = []
        bboxes_ls = []

        for node in self.nodes_dict:
            if node in self.coverage_dict:
                print(f"Node {node} covers range: {self.coverage_dict[node]}")
                bboxes_ls.append(list(self.coverage_dict[node]))
                print(tree.all_nodes.get(node).embeddings['OpenAI'].shape)
                patch_activations.append(tree.all_nodes.get(node).embeddings['OpenAI'])
            else:
                print(f"Node {node} does not have a defined coverage range")
        return torch.tensor(patch_activations), bboxes_ls