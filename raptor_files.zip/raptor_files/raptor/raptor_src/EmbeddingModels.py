import logging
from abc import ABC, abstractmethod
import time
from openai import OpenAI
from sentence_transformers import SentenceTransformer
from tenacity import retry, stop_after_attempt, wait_random_exponential

logging.basicConfig(format="%(asctime)s - %(message)s", level=logging.INFO)


class BaseEmbeddingModel(ABC):
    @abstractmethod
    def create_embedding(self, text):
        pass


class OpenAIEmbeddingModel(BaseEmbeddingModel):
    def __init__(self, model_name="sentence-transformers/msmarco-distilbert-base-tas-b"):
        print("ENTERED OpenAIEmbeddings")
        self.model = SentenceTransformer(model_name)

    def create_embedding(self, text):
        #print("OpenAI pass this into encoder")
        #print(text)
        #time.sleep(1) #introduce some delay for model to prepare
        encode_res = self.model.encode(text)
        #print("encode_res")
        #print(encode_res)
        return encode_res

class SBertEmbeddingModel(BaseEmbeddingModel):
    def __init__(self, model_name="sentence-transformers/msmarco-distilbert-base-tas-b"):
        #print("ENTERED SBERT!")
        self.model = SentenceTransformer(model_name)

    def create_embedding(self, text):
        #print("SBERT")
        return self.model.encode(text)
